// guacamole implements a HTTP client and a WebSocket client that connects to an Apache Guacamole
// server.
// This package is based on this work: https://github.com/wwt/guac
package guacamole
