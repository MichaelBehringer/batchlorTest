package proxy

// Proxy is a simple reverse proxy that proxies incoming requests
// to the defined destination and returns the response.
type Proxy struct {
}
